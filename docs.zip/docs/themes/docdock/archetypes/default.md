+++
title= "{{ replace .TranslationBaseName "-" " " | title }}"
date= {{ .Date }}
description = ""
draft= true
+++

Lorem Ipsum.
Notice `draft` is set to true.
